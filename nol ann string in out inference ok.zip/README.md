# noload_ann_rust
No-Load Artifical-Neural-Network (subsymbolic) for Inference and Embeddings; Rust (experimental)
